
# QLSinhVien_VBNet

Dự án mẫu quản lý sinh viên bằng VB.NET kết nối SQL Server.

## Các chức năng
- Thêm, Sửa, Xóa sinh viên
- Hiển thị danh sách trên DataGridView

## Cách sử dụng
1. Chạy file SQL trong thư mục SQL để tạo CSDL.
2. Mở project VB.NET trong Visual Studio.
3. Chạy chương trình, kiểm tra các chức năng.

