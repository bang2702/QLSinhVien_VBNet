
Imports System.Data.SqlClient

Public Class Form1
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        OpenConnect()
        LoadData()
    End Sub

    Private Sub LoadData()
        Dim da As New SqlDataAdapter("SELECT * FROM SinhVien", conn)
        Dim dt As New DataTable
        da.Fill(dt)
        DataGridView1.DataSource = dt
    End Sub

    Private Sub btnThem_Click(sender As Object, e As EventArgs) Handles btnThem.Click
        Dim sql As String = "INSERT INTO SinhVien VALUES(@MaSV,@HoTen,@NgaySinh,@GioiTinh)"
        Dim cmd As New SqlCommand(sql, conn)
        cmd.Parameters.AddWithValue("@MaSV", txtMaSV.Text)
        cmd.Parameters.AddWithValue("@HoTen", txtHoTen.Text)
        cmd.Parameters.AddWithValue("@NgaySinh", dtNgaySinh.Value)
        cmd.Parameters.AddWithValue("@GioiTinh", cboGioiTinh.Text)
        cmd.ExecuteNonQuery()
        LoadData()
    End Sub

    Private Sub btnXoa_Click(sender As Object, e As EventArgs) Handles btnXoa.Click
        Dim sql As String = "DELETE FROM SinhVien WHERE MaSV=@MaSV"
        Dim cmd As New SqlCommand(sql, conn)
        cmd.Parameters.AddWithValue("@MaSV", txtMaSV.Text)
        cmd.ExecuteNonQuery()
        LoadData()
    End Sub

    Private Sub btnSua_Click(sender As Object, e As EventArgs) Handles btnSua.Click
        Dim sql As String = "UPDATE SinhVien SET HoTen=@HoTen, NgaySinh=@NgaySinh, GioiTinh=@GioiTinh WHERE MaSV=@MaSV"
        Dim cmd As New SqlCommand(sql, conn)
        cmd.Parameters.AddWithValue("@MaSV", txtMaSV.Text)
        cmd.Parameters.AddWithValue("@HoTen", txtHoTen.Text)
        cmd.Parameters.AddWithValue("@NgaySinh", dtNgaySinh.Value)
        cmd.Parameters.AddWithValue("@GioiTinh", cboGioiTinh.Text)
        cmd.ExecuteNonQuery()
        LoadData()
    End Sub
End Class
