
Imports System.Data.SqlClient

Module DBConnect
    Public conn As SqlConnection
    Public Sub OpenConnect()
        Dim str As String = "Data Source=.;Initial Catalog=QLSinhVien;Integrated Security=True"
        conn = New SqlConnection(str)
        conn.Open()
    End Sub
End Module
